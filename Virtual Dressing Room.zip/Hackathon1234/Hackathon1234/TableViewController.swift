//
//  TableViewController.swift
//  Hackathon1234
//
//  Created by Vinoothna Manohar Botcha on 3/14/19.
//  Copyright © 2019 Vinoothna Manohar Botcha. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController {

    @IBOutlet var tableview: UITableView!
    
    let cellId = "FirstVC"
    
 /*
    func someMethodIWantToCall(cell: UITableViewCell) {
        
        guard let indexPathTapped = tableView.indexPath(for: cell) else { return }
        
        let contact = twodimensional[indexPathTapped.section].names[indexPathTapped.row]
        print(contact)
       
        let hasFavorited = contact.hasFavorited
        twodimensional[indexPathTapped.section].names[indexPathTapped.row].hasFavorited = !hasFavorited
        
        cell.accessoryView?.tintColor = hasFavorited ? UIColor.lightGray : .red

    }
   
     */
    var twodimensional = [
        ExpandableNames(isExpanded: true, names: ["Cool Shades"].map{ Contact(name: $0, hasFavorited: false) }),
        ExpandableNames(isExpanded: true, names: ["Shirts","Pants"].map{ Contact(name: $0, hasFavorited: false) }),
        ExpandableNames(isExpanded: true, names: ["Sarees","Long Frocks","Tops"].map{ Contact(name: $0, hasFavorited: false) })
                          
    ]
 
 
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = "Online Shopping"
        navigationController?.navigationBar.prefersLargeTitles = true
        UINavigationBar.appearance().barTintColor = .red
        UINavigationBar.appearance().tintColor = .white
        UINavigationBar.appearance().titleTextAttributes =  [NSAttributedString.Key.foregroundColor: UIColor.white]
        UINavigationBar.appearance().isTranslucent = false
        

        tableView.register( UITableViewCell.self, forCellReuseIdentifier: cellId)
        
    }

    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        
        let button = UIButton(type: .system)
        if twodimensional[section].names.count == 1{
            button.setTitle("Goggles", for: .normal)
        }
        else if twodimensional[section].names.count == 2{
            button.setTitle("Men's Wear", for: .normal)
        }
        else if twodimensional[section].names.count == 3{
            button.setTitle("Women's Wear", for: .normal)
        }
        button.setTitleColor(.black, for: .normal)
        button.backgroundColor = .yellow
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 14)
        
        button.addTarget(self, action: #selector(handleExpandClose), for: .touchUpInside)
        button.addTarget(self, action: #selector(handleExpandClose), for: .touchUpInside)
        
        button.tag = section
        
        return button
    
        
    }
    @objc func handleExpandClose(button: UIButton) {
        //print("Trying to expand and close section...")
        
        let section = button.tag
        
        var indexPaths = [IndexPath]()
        for row in twodimensional[section].names.indices {
            //print(0, row)
            let indexPath = IndexPath(row: row, section: section)
            indexPaths.append(indexPath)
            
        }

        
        
        let isExpanded = twodimensional[section].isExpanded
        twodimensional[section].isExpanded = !isExpanded
       
     
        
        
        if isExpanded {
            tableView.deleteRows(at: indexPaths, with: .fade)
        } else {
            tableView.insertRows(at: indexPaths, with: .fade)
        }
    }
    
    
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 36
    }
    
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return twodimensional.count
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if !twodimensional[section].isExpanded {
            return 0
        }
        return twodimensional[section].names.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: cellId, for: indexPath) //as! ContactCell
        //cell.link = self
        let contact = twodimensional[indexPath.section].names[indexPath.row]
        
        cell.textLabel?.text = contact.name
        
        cell.accessoryView?.tintColor = contact.hasFavorited ? UIColor.red : .lightGray
        
        cell.textLabel?.text = "\(contact.name) "
        
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        
        let storyboard = UIStoryboard(name: "Main" , bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "SecondVC") as! ViewController2
        vc.dataStr = twodimensional[indexPath.section].names[indexPath.row].name
       
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    

    // MARK: - Table view data source


 



}
