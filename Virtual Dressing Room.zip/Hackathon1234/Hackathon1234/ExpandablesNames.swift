//
//  ExpandablesNames.swift
//  Hackathon1234
//
//  Created by Vinoothna Manohar Botcha on 3/15/19.
//  Copyright © 2019 Vinoothna Manohar Botcha. All rights reserved.
//

import Foundation


struct ExpandableNames {
    var isExpanded: Bool
    var names: [Contact]
}

struct Contact {
    let name: String
    var hasFavorited: Bool
}
