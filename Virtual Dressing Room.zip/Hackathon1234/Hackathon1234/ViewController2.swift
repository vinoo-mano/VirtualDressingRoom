//
//  ViewController2.swift
//  Hackathon1234
//
//  Created by Vinoothna Manohar Botcha on 3/14/19.
//  Copyright © 2019 Vinoothna Manohar Botcha. All rights reserved.
//

import UIKit
import ARKit
import SceneKit

class ViewController2: UIViewController {

    @IBOutlet weak var sceneView: ARSCNView!
    var dataStr : String = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       let config = ARWorldTrackingConfiguration()
        config.planeDetection = .horizontal
        
        sceneView.session.run(config)
        
        
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func img1(_ sender: Any) {
        
        let cubenode = SCNNode(geometry: SCNBox(width: 0.1, height:  0.1, length: 0.1, chamferRadius: 0))
        //cubenode.position = SCNVector3(0, 0, )
        
        let cc = getCameraCoordinates(sceneView: sceneView)
        cubenode.position = SCNVector3(0, 0, -0.2)
        
        
        sceneView.scene.rootNode.addChildNode(cubenode)
        
    }
    
    @IBAction func img2(_ sender: Any) {
        
        let shirtNode = SCNNode()
        let cc = getCameraCoordinates(sceneView: sceneView)
        shirtNode.position = SCNVector3(-1, -1, -5)
        
        guard let virtualObjectScene = SCNScene(named: "6.scn", inDirectory: "Models.scnassets/2")
            
            else{
                print("cc")
                return
        }
        let wrapperNode = SCNNode()
        for child in virtualObjectScene .rootNode.childNodes{
            child.geometry?.firstMaterial?.lightingModel = .physicallyBased
            wrapperNode.addChildNode(child)
        }
        shirtNode.addChildNode(wrapperNode)
        
        sceneView.scene.rootNode.addChildNode(shirtNode)
    }
     

    
    struct myCoordinates {
        var x = Float()
        var y = Float()
        var z = Float()
    }
    
    func getCameraCoordinates(sceneView : ARSCNView) -> myCoordinates{
        
        let cameraTransform = sceneView.session.currentFrame?.camera.transform
        let cameraCoordinates = MDLTransform(matrix: cameraTransform!)
      
        var cc = myCoordinates()
        cc.z = cameraCoordinates.translation.z
        cc.y = cameraCoordinates.translation.y
        cc.x = cameraCoordinates.translation.x
        
        return cc
        
    }
    

}
