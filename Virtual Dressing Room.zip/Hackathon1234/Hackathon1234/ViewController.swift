//
//  ViewController.swift
//  Hackathon1234
//
//  Created by Vinoothna Manohar Botcha on 3/14/19.
//  Copyright © 2019 Vinoothna Manohar Botcha. All rights reserved.
//

import UIKit
import GoogleSignIn

class ViewController: UIViewController {
    

    @IBOutlet weak var UserNameField: UITextField!
    @IBOutlet weak var PasswordField: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        let signin = GIDSignInButton(frame: CGRect(x: 0, y: 0, width: 100, height: 100))
        
        signin.center = view.center
        view.addSubview(signin)
        
        
        let defaults = UserDefaults()
        defaults.set("vinoo", forKey: "Name")
        defaults.set("vinoo", forKey: "Password")
        defaults.synchronize()
        
        
        
    }

    @IBAction func Login(_ sender: Any) {
        
        
        if (UserNameField.text == "vinoo" && PasswordField.text == "vinoo"){
            
            _ = storyboard?.instantiateViewController(withIdentifier: "SecondVC") as! ViewController2
            
        }
        else{
            self.alert(name: "Login Failed")
        }
        
        
    }
    func alert(name: String){
        
        
        let alertController = UIAlertController(title:"KLU", message: name, preferredStyle: .alert)
        
        let alertAction = UIAlertAction(title: "cancel",style: .default, handler: nil)
        
        alertController.addAction(alertAction)
        
        self.present(alertController, animated: true, completion: nil)
        
    }
}

